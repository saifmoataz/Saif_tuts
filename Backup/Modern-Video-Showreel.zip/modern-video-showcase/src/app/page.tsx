import Header from '@/components/Header'
import ShowreelSection from '@/components/ShowreelSection'
import VideoGrid from '@/components/VideoGrid'
import DetailsSection from '@/components/DetailsSection'

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <ShowreelSection />
      <VideoGrid />
      <DetailsSection />
    </main>
  )
}
