'use client'

export default function ShowreelSection() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative bg-gradient-to-br from-emerald-50 via-teal-100 to-green-100 dark:from-slate-900 dark:via-emerald-900 dark:to-slate-900">
      {/* Background overlay */}
      <div className="absolute inset-0 bg-white/30 dark:bg-black/20" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-12">
          <h1 className="text-6xl md:text-8xl font-bold text-slate-800 dark:text-white mb-6 tracking-tight">
            SHOWREEL
          </h1>
          <p className="text-xl md:text-2xl text-slate-600 dark:text-white/80 max-w-3xl mx-auto leading-relaxed">
            Experience our creative journey through this carefully curated collection of our finest work
          </p>
        </div>

        {/* Main video */}
        <div className="max-w-5xl mx-auto">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-1000" />
            <div className="relative bg-black rounded-2xl overflow-hidden shadow-2xl">
              <iframe
                className="w-full aspect-video rounded-2xl"
                src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=0&controls=1&rel=0&showinfo=0&modestbranding=1"
                title="Main Showreel"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white/50 rounded-full mt-2" />
          </div>
        </div>
      </div>
    </section>
  )
}
